// This file holds the main code for plugins. Code in this file has access to
// the *figma document* via the figma global object.
// You can access browser APIs in the <script> tag inside "ui.html" which has a
// full browser environment (See https://www.figma.com/plugin-docs/how-plugins-run).

// This plugin creates rectangles on the screen.
const nodes: SceneNode[] = [];

// First, import the component from the library
figma.importComponentByKeyAsync('7473bc6b250a6792153b4482619b27b03b8f2bb8')
  .then(component => {
    // Once we have the component, create instances for each selected node
    figma.currentPage.selection.forEach(node => {
      const instance = component.createInstance();
      const absoluteBoundingBox = node.absoluteBoundingBox;
      
      if (absoluteBoundingBox) {
        instance.x = absoluteBoundingBox.x;
        instance.y = absoluteBoundingBox.y;
        instance.resize(node.width, node.height);
        instance.name = "Hotspot";
        figma.currentPage.appendChild(instance);
        nodes.push(instance);
      }
    });

    // Update selection and viewport
    figma.currentPage.selection = nodes;
    figma.viewport.scrollAndZoomIntoView(nodes);
    
    // Close the plugin
    figma.closePlugin();
  })
  .catch(error => {
    // Handle any errors (e.g., component not found)
    figma.notify(`Error: ${error.message}`);
    figma.closePlugin();
  });
